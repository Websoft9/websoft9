cockpit.locale({
 "": {
  "plural-forms": (n) => 0,
  "language": "id",
  "language-direction": "ltr"
 },
 "File browser": [
  null,
  "Penjelajah berkas"
 ],
 "explorer": [
  null,
  "penjelajah"
 ],
 "files": [
  null,
  "berkas"
 ],
 "filesystem": [
  null,
  "sistem berkas"
 ]
});
