cockpit.locale({
 "": {
  "plural-forms": (n) => 0,
  "language": "id",
  "language-direction": "ltr"
 },
 "\"$0\" exists, not overwriting with paste.": [
  null,
  "\"$0\" sudah ada, tidak menimpa dengan tempel (paste)."
 ],
 "$0 files": [
  null,
  "$0 berkas"
 ],
 "$0 files selected": [
  null,
  "$0 berkas dipilih"
 ],
 "$0 item is hidden": [
  null,
  "$0 item tersembunyi"
 ],
 "$0 permissions": [
  null,
  "$0 izin"
 ],
 "(original owner)": [
  null,
  "(pemilik asli)"
 ],
 "A file with the same name already exists in \"$0\". Replacing it will overwrite its content.": [
  null,
  "Berkas dengan nama yang sama sudah ada di \"$0\". Menggantikannya akan menimpa isinya."
 ],
 "A-Z": [
  null,
  "A-Z"
 ],
 "Absolute": [
  null,
  "Absolut"
 ],
 "Absolute symlinks are ideal when referring to files or directories that won't move, such as system files.": [
  null,
  "Tautan simbolik absolut ideal digunakan untuk merujuk pada berkas atau direktori yang tidak akan berpindah, seperti berkas sistem."
 ],
 "Absolute vs. Relative": [
  null,
  "Absolut vs. Relatif"
 ],
 "Access": [
  null,
  "Akses"
 ],
 "Activate selected item, enter directory": [
  null,
  "Aktifkan item yang dipilih, masuk ke direktori"
 ],
 "Add to bookmarks": [
  null,
  "Tambahkan ke penanda"
 ],
 "Apply this action to all conflicting files": [
  null,
  "Terapkan tindakan ini ke semua berkas yang bentrok"
 ],
 "Block device": [
  null,
  "Perangkat blok"
 ],
 "Bookmarks": [
  null,
  "Penanda"
 ],
 "Cancel": [
  null,
  "Batalkan"
 ],
 "Cancel upload of $0": [
  null,
  "Batalkan unggahan $0"
 ],
 "Cancelled": [
  null,
  "Dibatalkan"
 ],
 "Cancelled upload of $0": [
  null,
  "Unggahan $0 dibatalkan"
 ],
 "Cannot create file in current directory": [
  null,
  "Tidak dapat membuat berkas di direktori saat ini"
 ],
 "Cannot drop files, another upload is already in progress": [
  null,
  "Tidak dapat menjatuhkan berkas, unggahan lain sedang berlangsung"
 ],
 "Change": [
  null,
  "Ubah"
 ],
 "Change permissions": [
  null,
  "Ubah izin"
 ],
 "Change permissions for enclosed files": [
  null,
  "Ubah izin untuk berkas yang disertakan"
 ],
 "Character device": [
  null,
  "Perangkat karakter"
 ],
 "Clear filter": [
  null,
  "Hapus penyaring"
 ],
 "Close": [
  null,
  "Tutup"
 ],
 "Cockpit Files": [
  null,
  "Berkas Cockpit"
 ],
 "Collapse": [
  null,
  "Ciutkan"
 ],
 "Copy": [
  null,
  "Salin"
 ],
 "Copy selected file or directory": [
  null,
  "Salin berkas atau direktori yang dipilih"
 ],
 "Create": [
  null,
  "Buat"
 ],
 "Create directory": [
  null,
  "Buat direktori"
 ],
 "Create file": [
  null,
  "Buat berkas"
 ],
 "Create link": [
  null,
  "Buat tautan"
 ],
 "Create link to $0": [
  null,
  "Buat tautan ke $0"
 ],
 "Create new directory": [
  null,
  "Buat direktori baru"
 ],
 "Delete": [
  null,
  "Hapus"
 ],
 "Delete $0 items?": [
  null,
  "Hapus $0 item?"
 ],
 "Delete $0?": [
  null,
  "Hapus $0?"
 ],
 "Delete directory $0?": [
  null,
  "Hapus direktori $0?"
 ],
 "Delete file $0?": [
  null,
  "Hapus berkas $0?"
 ],
 "Delete link $0?": [
  null,
  "Hapus tautan $0?"
 ],
 "Directory": [
  null,
  "Direktori"
 ],
 "Directory contains $0 directories, $1 files": [
  null,
  "Direktori berisi $0 direktori, $1 berkas"
 ],
 "Directory contains $0 directories, $1 files, $2 hidden": [
  null,
  "Direktori berisi $0 direktori, $1 berkas, $2 tersembunyi"
 ],
 "Directory is empty": [
  null,
  "Direktori kosong"
 ],
 "Directory name": [
  null,
  "Nama direktori"
 ],
 "Directory name cannot be empty": [
  null,
  "Nama direktori tidak boleh kosong"
 ],
 "Directory name cannot include a /": [
  null,
  "Nama direktori tidak boleh mengandung /"
 ],
 "Directory name too long": [
  null,
  "Nama direktori terlalu panjang"
 ],
 "Directory owner": [
  null,
  "Pemilik direktori"
 ],
 "Directory with the same name exists": [
  null,
  "Direktori dengan nama yang sama sudah ada"
 ],
 "Display as a grid": [
  null,
  "Tampilkan sebagai kisi"
 ],
 "Display as a list": [
  null,
  "Tampilkan sebagai daftar"
 ],
 "Download": [
  null,
  "Unduh"
 ],
 "Drop files to upload": [
  null,
  "Jatuhkan berkas untuk diunggah"
 ],
 "Edit $0": [
  null,
  "Sunting $0"
 ],
 "Edit path": [
  null,
  "Sunting jalur"
 ],
 "Edit permissions": [
  null,
  "Sunting izin"
 ],
 "Editing": [
  null,
  "Menyunting"
 ],
 "Execute-only": [
  null,
  "Hanya-eksekusi"
 ],
 "Failed": [
  null,
  "Gagal"
 ],
 "File exists": [
  null,
  "Berkas sudah ada"
 ],
 "File name": [
  null,
  "Nama berkas"
 ],
 "File uploaded": [
  null,
  "Berkas berhasil diunggah"
 ],
 "Filename is the same as original name": [
  null,
  "Nama berkas sama dengan nama aslinya"
 ],
 "Files being pasted have a different owner. By default, ownership will be changed to match the destination directory.": [
  null,
  "Berkas yang ditempel memiliki pemilik yang berbeda. Secara bawaan, kepemilikan akan diubah agar sesuai dengan direktori tujuan."
 ],
 "Files uploaded": [
  null,
  "Berkas berhasil diunggah"
 ],
 "Filesystem": [
  null,
  "Sistem berkas"
 ],
 "Filter directory": [
  null,
  "Saring direktori"
 ],
 "First modified": [
  null,
  "Pertama diubah"
 ],
 "Force delete $0": [
  null,
  "Paksa hapus $0"
 ],
 "Force delete $0 items": [
  null,
  "Paksa hapus $0 item"
 ],
 "Force delete directory $0?": [
  null,
  "Paksa hapus direktori $0?"
 ],
 "Force delete file $0?": [
  null,
  "Paksa hapus berkas $0?"
 ],
 "Force delete link $0?": [
  null,
  "Paksa hapus tautan $0?"
 ],
 "Go back": [
  null,
  "Kembali"
 ],
 "Go forward": [
  null,
  "Maju"
 ],
 "Go up a directory": [
  null,
  "Naik satu direktori"
 ],
 "Group": [
  null,
  "Grup"
 ],
 "Group access": [
  null,
  "Akses grup"
 ],
 "Hide hidden items": [
  null,
  "Sembunyikan item tersembunyi"
 ],
 "Home": [
  null,
  "Beranda"
 ],
 "Ignore": [
  null,
  "Abaikan"
 ],
 "Keep original": [
  null,
  "Pertahankan yang asli"
 ],
 "Keyboard shortcuts": [
  null,
  "Pintasan keyboard"
 ],
 "Largest size": [
  null,
  "Ukuran terbesar"
 ],
 "Last modified": [
  null,
  "Terakhir diubah"
 ],
 "Least permissive": [
  null,
  "Paling terbatas"
 ],
 "Missing type": [
  null,
  "Jenis hilang"
 ],
 "Modified": [
  null,
  "Diubah"
 ],
 "Most permissive": [
  null,
  "Paling permisif"
 ],
 "Name": [
  null,
  "Nama"
 ],
 "Name cannot be empty": [
  null,
  "Nama tidak boleh kosong"
 ],
 "Name cannot include a /": [
  null,
  "Nama tidak boleh mengandung /"
 ],
 "Name too long": [
  null,
  "Nama terlalu panjang"
 ],
 "Named pipe": [
  null,
  "Pipa bernama"
 ],
 "Navigation": [
  null,
  "Navigasi"
 ],
 "New file": [
  null,
  "Berkas baru"
 ],
 "New filename": [
  null,
  "Nama berkas baru"
 ],
 "New name": [
  null,
  "Nama baru"
 ],
 "New owner": [
  null,
  "Pemilik baru"
 ],
 "No access": [
  null,
  "Tidak ada akses"
 ],
 "No matching results": [
  null,
  "Tidak ada hasil yang cocok"
 ],
 "None": [
  null,
  "Tidak ada"
 ],
 "Open in terminal": [
  null,
  "Buka di terminal"
 ],
 "Open text file": [
  null,
  "Buka berkas teks"
 ],
 "Original file on server": [
  null,
  "Berkas asli di server"
 ],
 "Others": [
  null,
  "Lainnya"
 ],
 "Others access": [
  null,
  "Akses lainnya"
 ],
 "Overwrite": [
  null,
  "Timpa"
 ],
 "Owner": [
  null,
  "Pemilik"
 ],
 "Owner access": [
  null,
  "Akses pemilik"
 ],
 "Owner ascending": [
  null,
  "Pemilik menaik"
 ],
 "Owner descending": [
  null,
  "Pemilik menurun"
 ],
 "Ownership": [
  null,
  "Kepemilikan"
 ],
 "Paste": [
  null,
  "Tempel"
 ],
 "Paste as owner": [
  null,
  "Tempel sebagai pemilik"
 ],
 "Paste file or directory": [
  null,
  "Tempel berkas atau direktori"
 ],
 "Pasting failed": [
  null,
  "Gagal menempel"
 ],
 "Permission denied": [
  null,
  "Izin ditolak"
 ],
 "Permissions": [
  null,
  "Izin"
 ],
 "Permissions for $0 files": [
  null,
  "Izin untuk $0 berkas"
 ],
 "Read and execute": [
  null,
  "Baca dan eksekusi"
 ],
 "Read and write": [
  null,
  "Baca dan tulis"
 ],
 "Read, write, and execute": [
  null,
  "Baca, tulis, dan eksekusi"
 ],
 "Read-only": [
  null,
  "Hanya-baca"
 ],
 "Regular file": [
  null,
  "Berkas biasa"
 ],
 "Relative": [
  null,
  "Relatif"
 ],
 "Relative symlinks are useful when both a symlink and target might move at the same time, such as when renaming or moving a parent directory.": [
  null,
  "Tautan simbolik relatif berguna ketika tautan dan target dapat berpindah bersamaan, seperti saat mengganti nama atau memindahkan direktori induk."
 ],
 "Reload": [
  null,
  "Muat ulang"
 ],
 "Remove from bookmarks": [
  null,
  "Hapus dari penanda"
 ],
 "Rename": [
  null,
  "Ganti nama"
 ],
 "Rename $0?": [
  null,
  "Ganti nama $0?"
 ],
 "Rename selected file or directory": [
  null,
  "Ganti nama berkas atau direktori yang dipilih"
 ],
 "Replace": [
  null,
  "Ganti"
 ],
 "Replace file $0?": [
  null,
  "Ganti berkas $0?"
 ],
 "Save": [
  null,
  "Simpan"
 ],
 "Security context": [
  null,
  "Konteks keamanan"
 ],
 "Select all": [
  null,
  "Pilih semua"
 ],
 "Set executable as program": [
  null,
  "Atur eksekusi sebagai program"
 ],
 "Show all files": [
  null,
  "Tampilkan semua berkas"
 ],
 "Show hidden items": [
  null,
  "Tampilkan item tersembunyi"
 ],
 "Show keyboard shortcuts": [
  null,
  "Tampilkan pintasan keyboard"
 ],
 "Size": [
  null,
  "Ukuran"
 ],
 "Smallest size": [
  null,
  "Ukuran terkecil"
 ],
 "Socket": [
  null,
  "Soket"
 ],
 "Sort": [
  null,
  "Urutkan"
 ],
 "Symbolic link": [
  null,
  "Tautan simbolik"
 ],
 "Symlink name": [
  null,
  "Nama tautan simbolik"
 ],
 "Target": [
  null,
  "Target"
 ],
 "The existing file changed unexpectedly": [
  null,
  "Berkas yang ada berubah secara tidak terduga"
 ],
 "The file has been removed on disk": [
  null,
  "Berkas telah dihapus dari disk"
 ],
 "The file has changed on disk": [
  null,
  "Berkas telah berubah di disk"
 ],
 "Type": [
  null,
  "Jenis"
 ],
 "Unable to create bookmark directory": [
  null,
  "Tidak dapat membuat direktori penanda"
 ],
 "Unable to move uploaded file to final destination": [
  null,
  "Tidak dapat memindahkan berkas yang diunggah ke tujuan akhir"
 ],
 "Unable to save bookmark file": [
  null,
  "Tidak dapat menyimpan berkas penanda"
 ],
 "Upload": [
  null,
  "Unggah"
 ],
 "Upload $0% completed": [
  null,
  "Unggahan $0% selesai"
 ],
 "Upload error": [
  null,
  "Kesalahan unggahan"
 ],
 "Uploaded as $0, $1": [
  null,
  "Diunggah sebagai $0, $1"
 ],
 "Uploads": [
  null,
  "Unggahan"
 ],
 "User": [
  null,
  "Pengguna"
 ],
 "View $0": [
  null,
  "Lihat $0"
 ],
 "Write and execute": [
  null,
  "Tulis dan eksekusi"
 ],
 "Write-only": [
  null,
  "Hanya-tulis"
 ],
 "Z-A": [
  null,
  "Z-A"
 ],
 "keep original owners": [
  null,
  "pertahankan pemilik asli"
 ],
 "link to $0": [
  null,
  "tautkan ke $0"
 ]
});
